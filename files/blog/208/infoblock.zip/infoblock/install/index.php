<?php
/*
 * Файл local/modules/infoblock/install/index.php
 */

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Application;
use Bitrix\Main\IO\Directory;

Loc::loadMessages(__FILE__);

class infoblock extends CModule {

    public function __construct() {
        if (is_file(__DIR__.'/version.php')){
            include_once(__DIR__.'/version.php');
            $this->MODULE_ID           = get_class($this);
            $this->MODULE_VERSION      = $arModuleVersion['VERSION'];
            $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
            $this->MODULE_NAME         = Loc::getMessage('INFOBLOCK_NAME');
            $this->MODULE_DESCRIPTION  = Loc::getMessage('INFOBLOCK_DESCRIPTION');
        } else {
            CAdminMessage::ShowMessage(
                Loc::getMessage('INFOBLOCK_FILE_NOT_FOUND').' version.php'
            );
        }
    }
    
    public function DoInstall() {

        global $APPLICATION;

        // мы используем функционал нового ядра D7 — поддерживает ли его система?
        if (CheckVersion(ModuleManager::getVersion('main'), '14.00.00')) {
            // копируем файлы, необходимые для работы модуля
            $this->InstallFiles();
            // регистрируем модуль в системе
            ModuleManager::registerModule($this->MODULE_ID);
        } else {
            CAdminMessage::ShowMessage(
                Loc::getMessage('INFOBLOCK_INSTALL_ERROR')
            );
            return;
        }

        $APPLICATION->IncludeAdminFile(
            Loc::getMessage('INFOBLOCK_INSTALL_TITLE').' «'.Loc::getMessage('INFOBLOCK_NAME').'»',
            __DIR__.'/step.php'
        );
    }
    
    public function InstallFiles() {
        // копируем файлы компонентов, которые устанавливаем вместе с модулем;
        // пространством имен для компонентов будет имя модуля, т.е. infoblock
        CopyDirFiles(
            __DIR__.'/assets/components',
            Application::getDocumentRoot().'/local/components/'.$this->MODULE_ID.'/',
            true,
            true
        );
    }

    public function DoUninstall() {

        global $APPLICATION;

        $this->UnInstallFiles();

        ModuleManager::unRegisterModule($this->MODULE_ID);

        $APPLICATION->IncludeAdminFile(
            Loc::getMessage('INFOBLOCK_UNINSTALL_TITLE').' «'.Loc::getMessage('INFOBLOCK_NAME').'»',
            __DIR__.'/unstep.php'
        );

    }

    public function UnInstallFiles() {
        // удаляем файлы компонента, который установили вместе с модулем
        Directory::deleteDirectory(
            Application::getDocumentRoot().'/local/components/'.$this->MODULE_ID
        );
        // удаляем настройки нашего модуля
        Option::delete($this->MODULE_ID);
    }

}