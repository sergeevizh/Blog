<?php
/*
 * Файл local/modules/infoblock/install/version.php
 */

$arModuleVersion = array(
    'VERSION'      => '1.0.0',
    'VERSION_DATE' => '2018-10-26 14:00:00'
);