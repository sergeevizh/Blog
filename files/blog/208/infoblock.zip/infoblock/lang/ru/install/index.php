<?php
/*
 * Файл local/modules/infoblock/lang/ru/install/index.php
 */

$MESS['INFOBLOCK_NAME']              = 'Компонент «Инфоблок»';
$MESS['INFOBLOCK_DESCRIPTION']       = 'Устанавливает универсальный компонент для работы с инфоблоками';

$MESS['INFOBLOCK_FILE_NOT_FOUND']    = 'Не найден файл';
$MESS['INFOBLOCK_INSTALL_TITLE']     = 'Установка модуля';
$MESS['INFOBLOCK_INSTALL_ERROR']     = 'Версия главного модуля ниже 14, обновите систему.';
$MESS['INFOBLOCK_INSTALL_SUCCESS']   = 'Модуль успешно установлен';
$MESS['INFOBLOCK_INSTALL_FAILED']    = 'Ошибка при установке модуля';

$MESS['INFOBLOCK_UNINSTALL_TITLE']   = 'Удаление модуля';
$MESS['INFOBLOCK_UNINSTALL_SUCCESS'] = 'Модуль успешно удален';
$MESS['INFOBLOCK_UNINSTALL_FAILED']  = 'Ошибка при удалении модуля';

$MESS['INFOBLOCK_RETURN_MODULES']    = 'Вернуться в список модулей';
