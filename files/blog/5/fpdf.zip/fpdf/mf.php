<?php
require('makefont/makefont.php');
/*
MakeFont('arial.ttf', 'cp1251');
MakeFont('arialbd.ttf', 'cp1251');
MakeFont('ariali.ttf', 'cp1251');
MakeFont('arialbi.ttf', 'cp1251');

MakeFont('times.ttf', 'cp1251');
MakeFont('timesbd.ttf', 'cp1251');
MakeFont('timesi.ttf', 'cp1251');
MakeFont('timesbi.ttf', 'cp1251');
*/
MakeFont('cour.ttf', 'cp1251');
MakeFont('courbd.ttf', 'cp1251');
MakeFont('couri.ttf', 'cp1251');
MakeFont('courbi.ttf', 'cp1251');
?>