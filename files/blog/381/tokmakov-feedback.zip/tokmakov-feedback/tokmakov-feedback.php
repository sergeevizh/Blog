<?php
/*
Plugin Name: Форма обратной связи
Plugin URI: https://tokmakov.msk.ru
Description: Регистрирует шорткод [tokmakov-feedback] для формы обратной связи.
Version: 1.0
Author: Евгений Токмаков
Author URI: https://tokmakov.msk.ru
*/

register_activation_hook(__FILE__, function() {
	// проверяем права пользователя на установку плагинов
	if (!current_user_can('activate_plugins')) {
		return;
	}
});

register_deactivation_hook(__FILE__, function() {
	// проверяем права пользователя на деактивацию плагинов
	if (!current_user_can('deactivate_plugins')) {
		return;
	}
});

/*
 * Обработка данных формы при использовании XmlHttpRequest (AJAX)
 */
if (wp_doing_ajax()) {
	if (session_id() == '') {
		session_start();
	}
	add_action('wp_ajax_tokmakov_feedback', 'tokmakov_process_feedback_form');
	add_action('wp_ajax_nopriv_tokmakov_feedback', 'tokmakov_process_feedback_form');
	// когда пришел ajax-запрос c данными формы, нам больше ничего
	// делать не надо, так что прерываем работу плагина и выходим
	return;
}

/*
 * Запускаем сессию, чтобы передавать сообщение о результате
 * обработки формы обратной связи после перезагрузки страницы
 */
add_action('init', function () {
	if (session_id() == '') {
		session_start();
	}
});

/*
 * Регистрируем шорткод [tokmakov-feedback], который позволит
 * вставить форму загрузки файлов на страницу или запись блога
 */
add_shortcode('tokmakov-feedback', function () {
	$name = '';
	$email = '';
	$phone = '';
	$message = '';
	if (isset($_SESSION['tokmakov_feedback']['data'])) {
		$name = htmlspecialchars($name);
		$email = htmlspecialchars($email);;
		$phone = htmlspecialchars($phone);;
		$message = htmlspecialchars($message);;
	}
	ob_start();
	?>
	<div class="tokmakov-feedback">
		<div class="response">
			<?php if (isset($_SESSION['tokmakov_feedback'])): ?>
				<p><?= $_SESSION['tokmakov_feedback']['message']; ?></p>
				<?php if (isset($_SESSION['tokmakov_feedback']['errors'])): ?>
					<ul>
						<?php foreach ($_SESSION['tokmakov_feedback']['errors'] as $error): ?>
							<li><?= $error; ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php unset($_SESSION['tokmakov_feedback']); ?>
			<?php endif; ?>
		</div>
		<form action="<?= admin_url('admin-post.php'); ?>" method="post">
			<input type="hidden" name="action" value="tokmakov_feedback" />
			<input type="hidden" name="redirect" value="<?= get_permalink(); ?>" />
			<label>
				<span>Имя</span>
				<input type="text" name="name" value="<?= $name; ?>" />
			</label>
			<label>
				<span>E-mail</span>
				<input type="text" name="email" value="<?= $email; ?>" />
			</label>
			<label>
				<span>Телефон</span>
				<input type="text" name="phone" value="<?= $phone; ?>" />
			</label>
			<label>
				<span>Сообщение</span>
				<textarea name="message"><?= $message; ?></textarea>
			</label>
			<label>
				<span>Защитный код</span>
				<input type="text" name="captcha" value="" />
				<img src="<?= plugin_dir_url(__FILE__) ?>captcha.php" alt="" />
			</label>
			<input type="submit" value="Отправить" />
		</form>
	</div>
	<?php
	return ob_get_clean();
});

/*
 * Подключаем js и css файлы, необходимые для работы плагина
 */
add_action('wp_enqueue_scripts', function () {
	wp_enqueue_script(
		'tokmakov-feedback-js',
		plugin_dir_url(__FILE__) . 'script.js',
		['jquery'],
		null,
		true
	);
	// определяем глобальную js-переменную, которая будет
	// содержать URL, куда отправлять ajax-запросы
	wp_localize_script(
		'tokmakov-feedback-js',
		'tokmakov_feedback',
		[
			'handler' => admin_url('admin-ajax.php'),
			'loader' => plugin_dir_url(__FILE__) . 'loader.gif'
		]
	);
	wp_enqueue_style(
		'tokmakov-feedback-css',
		plugin_dir_url(__FILE__) . 'style.css'
	);
});

/*
 * Обрабатываем отправленные данные формы обратной связи
 */
add_action('admin_post_nopriv_tokmakov_feedback', 'tokmakov_process_feedback_form');
add_action('admin_post_tokmakov_feedback', 'tokmakov_process_feedback_form');

function tokmakov_process_feedback_form() {
	/*
	 * Обрабатываем данные, полученные из формы
	 */
	$data['name']    = trim(iconv_substr(strip_tags($_POST['name']), 0, 50));
	$data['email']   = trim(iconv_substr(strip_tags($_POST['email']), 0, 50));
	$data['phone']   = trim(iconv_substr(strip_tags($_POST['phone']), 0, 50));
	$data['message'] = trim(iconv_substr(strip_tags($_POST['message']), 0, 1000));
	$data['captcha'] = trim(iconv_substr(strip_tags($_POST['captcha']), 0, 4));

	// были допущены ошибки при заполнении формы?
	if (empty($data['name'])) {
		$errors[] = 'Не заполнено обязательное поле «Имя»';
	}
	if (empty($data['email'])) {
		$errors[] = 'Не заполнено обязательное поле «E-mail»';
	}
	if (empty($data['message'])) {
		$errors[] = 'Не заполнено обязательное поле «Сообщение»';
	}
	if (!empty($data['captcha'])) {
		if ($data['captcha'] != $_SESSION['tokmakov_feedback_captcha']) {
			$errors[] = 'Не совпадает защитный код с картинки';
		}
	} else {
		$errors[] = 'Не заполнено обязательное поле «Защитный код»';
	}

	if (!empty($errors)) {
		/*
		 * были допущены ошибки при заполнении формы, сохраняем введенные
		 * пользователем данные, чтобы после редиректа снова показать форму,
		 * заполненную введенными ранее даннными и сообщением об ошибке
		 */
		$response['success'] = false;
		$message = 'При заполнении формы были допущены ошибки';
		$response['message'] = $message;
		$response['errors'] = $errors;
		$response['data'] = $data;
	} else {
		// отправляем письмо администратору
		if (tokmakov_sendmail($data)) {
			$response['success'] = true;
			$message = 'Ваше сообщение успешно отправлено';
			$response['message'] = $message;
		} else {
			$response['success'] = false;
			$message = 'Произошла ошибка при отправке письма';
			$response['message'] = $message;
			$response['data'] = $data;
		}
	}

	if (!wp_doing_ajax()) {
		$_SESSION['tokmakov_feedback'] = $response;
		$redirect = home_url();
		if (isset($_POST['redirect'])) {
			$redirect = $_POST['redirect'];
			$redirect = wp_validate_redirect($redirect, home_url());
		}
		wp_redirect($redirect);
		die();
	} else {
		wp_send_json($response);
	}
}

function tokmakov_sendmail($data) {
	$message = 'Имя: ' . $data['name'] . PHP_EOL;
	$message .= 'E-mail: ' . $data['email'] . PHP_EOL;
	if (!empty($data['phone'])) {
		$message .= 'Телефон: ' . $data['phone'] . PHP_EOL;
	}
	$message .= PHP_EOL . 'Сообщение: ' . PHP_EOL . $data['message'] . PHP_EOL;
	$result = wp_mail(
		get_bloginfo('admin_email'),
		'Заполнена форма обратной связи',
		$message
	);
	return $result;
}