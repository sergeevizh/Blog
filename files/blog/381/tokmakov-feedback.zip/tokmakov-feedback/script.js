jQuery(document).ready(function($) {
	/*
	 * Скрываем блок, где будут результаты, чтобы потом красиво показать
	 */
	$('.tokmakov-feedback .response').hide();
	/*
	 * Добавляем loader, который будем показывать в момент отправки
	 */
	var attr = {'src': tokmakov_feedback.loader, 'class': 'loader'};
	var $image = $('<img>', attr).hide();
	$('.tokmakov-feedback form').append($image);
	/*
	 * Подписываемся на событие submit, отменяем обычную отправку формы
	 */
	$('.tokmakov-feedback form').on('submit', function(e) {
		// отменяем обычную отправку формы
		e.preventDefault();
		// сама форма, блок с ответом, loader и кнопка отправки
		var $form = $(this),
			$response = $form.siblings('.response'),
			$loader = $form.children('.loader'),
			$submit = $form.children('input[type=submit]');
		// блокируем кнопку submit и показываем loader
		$submit.prop('disabled', true);
		$loader.show();
		// передаем форму не объектом jQuery, а как DOM-элемент
		var data = new FormData($form[0]);
		// отправляем данные формы
		$.ajax({
			url: tokmakov_feedback.handler,
			type: $form.attr('method'),
			data: data,
			contentType: false, // убираем форматирование данных по умолчанию
			processData: false, // убираем преобразование строк по умолчанию
			dataType: 'json',
			success: function(response) {
				// разблокируем кнопку submit и скрываем loader
				$submit.prop('disabled', false);
				$loader.hide();
				// создаем абзац текста с ответом сервера
				$('<p>').appendTo($response).text(response.message);
				// если были ошибки, создаем список ошибок
				if (response.errors) {
					var $errors = $('<ul>').appendTo($response);
					response.errors.forEach(function(item) {
						$('<li>').text(item).appendTo($errors);
					});
				}
				// показываем ответ и ошибки с использованмием анимации
				$response
					.slideDown(500)
					.delay(2000)
					.slideUp(500, function () {
						$(this).empty();
						// если сообщение отправлено, очищаем форму
						if (response.success) {
							$form[0].reset();
						}
					});
			}
		});
	});
});