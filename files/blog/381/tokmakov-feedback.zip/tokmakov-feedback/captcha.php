<?php
session_start();

// создаем случайное число и сохраняем в сессии
$number = rand(1000, 9999);
$_SESSION['tokmakov_feedback_captcha'] = $number;

// создаем изображение
$img = imagecreatetruecolor(75, 25);

// создаем три цвета: для числа, для шума и для фона
$white = imagecolorallocate($img, 230, 230, 230);
$grey = imagecolorallocate($img, 150, 150, 150);
$black = imagecolorallocate($img, 50, 50, 50);

imagefilledrectangle($img, 0, 0, 105, 25, $black);

// рисуем созданное случайное число
imagettftext($img, 20, 0, 10, 19, $grey, 'font.ttf', rand(1000, 9999));
imagettftext($img, 20, 0, 0, 22, $white, 'font.ttf', $number);

// предотвращаем кеширование браузером
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Expires: ' . date('r'));

// отправляем изображение браузеру
header ('Content-type: image/gif');
imagegif($img);
imagedestroy($img);
