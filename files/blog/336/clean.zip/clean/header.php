<?php
/**
 * Шапка сайта, подключается на всех страницах сайта
 */
?>

<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<header>
	<?php
	/*
	 * Фоновое изображение шапки сайта. Если пользователь не загрузил
	 * изображение, то оно не будет показано
	 */
	$style = '';
	if (has_custom_header()) {
		$style = ' style="background-image: url('.get_header_image().')"';
	}
	?>
	<div<?= $style; ?>>
		<div class="container">
			<span id="blogname" style="color: #<?php header_textcolor(); ?>">
				<?php bloginfo('name'); ?>
			</span>
			<span id="blogdescription" style="color: #<?php header_textcolor(); ?>">
				<?php bloginfo('description'); ?>
			</span>
		</div>
	</div>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				<a href="<?= home_url(); ?>"
				   class="navbar-brand<?= is_front_page() ? ' active': ''; ?>">
					<span class="glyphicon glyphicon-home"></span>
				</a>
			</div>
			<div class="collapse navbar-collapse" id="main-menu">
				<?php
				wp_nav_menu([
					'theme_location'  => 'header_menu',
					'container'       => false,
					'menu_class'      => 'nav navbar-nav',
					'menu_id'         => 'main-menu-ul',
				]);
				?>
				<div class="navbar-right">
					<?php if ( ! is_user_logged_in()): ?>
						<a href="<?= wp_registration_url(); ?>"
						   class="btn btn-default navbar-btn">
							<?php _e('Регистрация', 'clean'); ?>
						</a>
					<?php endif; ?>
					<?php if ( ! is_user_logged_in()): ?>
						<a href="<?= wp_login_url(get_permalink()); ?>"
						   class="btn btn-default navbar-btn">
							<?php _e('Войти', 'clean'); ?>
						</a>
					<?php else: ?>
						<a href="<?= wp_logout_url(get_permalink()); ?>"
						   class="btn btn-default navbar-btn">
							<?php _e('Выйти', 'clean'); ?>
						</a>
					<?php endif; ?>
				</div>
				<?php get_search_form(); ?>
			</div>
		</div>
	</nav>
</header>
