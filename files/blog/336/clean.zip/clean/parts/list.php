<?php
/**
 * Список записей с постраничной навигацией, файл parts/list.php
 */
?>

<?php if (have_posts()): ?>
	<ul class="media-list">
		<?php while (have_posts()): ?>
			<?php the_post(); ?>
			<li class="media well">
				<div class="media-left">
					<?php
					$default = get_template_directory_uri().'/assets/img/default-background.jpg';
					$thumbnail = get_the_post_thumbnail_url(null, 'thumbnail') ?: $default;
					?>
					<img class="media-object" src="<?= $thumbnail; ?>" alt="">
				</div>
				<div class="media-body">
					<h4 class="media-heading"><?php the_title(); ?></h4>
					<p><?php the_excerpt(); ?></p>
					<p>
						<a href="<?php the_permalink(); ?>" class="btn btn-default">
							<?php _e('Читать дальше', 'clean'); ?>
						</a>
					</p>
				</div>
			</li>
		<?php endwhile; ?>
	</ul>
	<?php echo_posts_pagination(); ?>
<?php else: ?>
	<p><?php _e('Ничего не найдено', 'clean'); ?></p>
<?php endif; ?>
