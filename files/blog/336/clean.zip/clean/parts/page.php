<?php
/**
 * Шаблон для страницы сайта (тип записи page), файл parts/page.php
 */
?>

<?php if (have_posts()): ?>
	<div id="clean-page">
		<h1><?php the_title(); ?></h1>
		<?php the_post(); ?>
		<?php the_content(); ?>
	</div>
<?php endif; ?>
