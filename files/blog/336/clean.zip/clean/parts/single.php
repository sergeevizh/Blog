<?php
/**
 * Шаблон для показа отдельной записи произвольного типа,
 * кроме page. Файл parts/single.php
 */
?>

<?php if (have_posts()): ?>
	<div id="clean-single">
		<?php the_post(); ?>
		<h1><?php the_title(); ?></h1>
		<?php the_content(); ?>
		<ul class="pager">
			<li class="previous">
				<?php
				previous_post_link(
					'%link',
					__('Предыдущая', 'clean')
				);
				?>
			</li>
			<li class="next">
				<?php
				next_post_link(
					'%link',
					__('Следующая', 'clean')
				);
				?>
			</li>
		</ul>
	</div>
	<?php comments_template(); ?>
<?php endif; ?>
