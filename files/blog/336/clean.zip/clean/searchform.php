<?php
/**
 * Шаблон формы поиска, файл searchform.php
 */
?>

<form method="get"
      action="<?= home_url('/'); ?>"
      id="searchform"
      class="navbar-form navbar-right"
      role="search">
	<div class="form-group">
		<input type="text"
		       name="s"
		       id="s"
		       value="<?= get_search_query(); ?>"
		       class="form-control"
		       placeholder="Поиск по сайту">
	</div>
	<button type="submit" class="btn btn-default">Искать</button>
</form>
