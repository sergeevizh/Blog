<?php
/**
 * Шаблон для показа отдельной записи произвольного типа,
 * кроме страниц (тип page). Файл single.php
 */

/*
 * Подключаем шапку сайта
 */
get_header();
?>

<div id="content">
	<div class="container">
		<div class="row">
			<main class="col-md-9">
				<?php get_template_part('parts/single'); ?>
			</main>
			<aside class="col-md-3">
				<?php get_sidebar(); ?>
			</aside>
		</div>
	</div>
</div>

<?php
/*
 * Подключаем подвал сайта
 */
get_footer();
