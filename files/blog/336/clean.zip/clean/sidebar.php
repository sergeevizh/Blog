<?php
/**
 * Сайдбар, файл sidebar.php
 */
?>

<?php if (is_active_sidebar('sidebar_right')): ?>
    <div id="sidebar_right" class="sidebar">
        <?php dynamic_sidebar('sidebar_right'); ?>
    </div>
<?php endif; ?>
