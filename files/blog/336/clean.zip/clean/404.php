<?php
/**
 * Шаблон для страницы 404 Not Found, файл 404.php
 */

/*
 * Подключаем шапку сайта
 */
get_header();
?>

<div id="content">
	<div class="container">
		<div class="row">
			<main id="clean-notfound">
				<h1><?php _e('Страница не найдена', 'clean'); ?></h1>
				<p>
				<?php
				_e(
					'Запрошенная страница не найдена, попробуйте воспользоваться поиском.',
					'clean'
				);
				?>
				</p>

				<?php
				// поиск по сайту
				the_widget('WP_Widget_Search');
				// категории блога
				the_widget('WP_Widget_Categories');
				// свежие записи
				the_widget( 'WP_Widget_Recent_Posts' );
				// сттаницы сайта
				the_widget('WP_Widget_Pages');
				// облако тегов
				the_widget('WP_Widget_Tag_Cloud');
				?>
			</main>
		</div>
	</div>
</div>

<?php
/*
 * Подключаем подвал сайта
 */
get_footer();
