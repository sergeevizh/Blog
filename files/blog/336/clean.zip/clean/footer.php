<?php
/**
 * Подвал сайта, подключается на всех страницах сайта
 */
?>

<footer>
	<div class="container">
		<div class="row">
			<div class="text-center">
				<p>&copy; All Rights Reserved.</p>
			</div>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
