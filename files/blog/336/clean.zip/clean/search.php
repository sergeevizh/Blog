<?php
/**
 * Шаблон для показа результатов поиска по сайту, файл search.php
 */

/*
 * Подключаем шапку сайта
 */
get_header();
?>

<div id="content">
	<div class="container">
		<div class="row">
			<main class="col-md-9">
				<h1><?php esc_html_e( 'Поиск по сайту', 'clean' ); ?></h1>
				<?php if (!empty(get_search_query())): ?>
					<h2>
						<?php
						esc_html_e( 'Результаты поиска для: ', 'clean' );
						echo get_search_query();
						?>
					</h2>
				<?php endif; ?>
				<?php get_template_part('parts/list'); ?>
			</main>
			<aside class="col-md-3">
				<?php get_sidebar(); ?>
			</aside>
		</div>
	</div>
</div>

<?php
/*
 * Подключаем подвал сайта
 */
get_footer();

