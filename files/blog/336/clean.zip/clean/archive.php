<?php
/**
 * Шаблон для показа списка архивных записей, файл archive.php
 */

/*
 * Подключаем шапку сайта
 */
get_header();
?>

<div id="content">
	<div class="container">
		<div class="row">
			<main class="col-md-9">
				<h1><?php the_archive_title(); ?></h1>
				<p><?php the_archive_description(); ?></p>
				<?php get_template_part('parts/list'); ?>
			</main>
			<aside class="col-md-3">
				<?php get_sidebar(); ?>
			</aside>
		</div>
	</div>
</div>

<?php
/*
 * Подключаем подвал сайта
 */
get_footer();
