<?php
/*
 * Когда пользователь изменяет настройки темы в Theme Customizer и
 * наблюдает изменения в окне предварительного просмотра
 */
add_action(
	'customize_register',
	function($wp_customize) {
		/*
		 * Обновление окна предварительного просмотра настроек темы без перезагрузки
		 */
		$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
		$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
		$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '#blogname',
				'render_callback' => function() {
					bloginfo( 'name' );
				}
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '#blogdescription',
				'render_callback' => function() {
					bloginfo( 'description' );
				}
			)
		);
	}
);

/*
 * Подключаем js-файл, который будет обновлять без перезагрузки окно
 * предварительного просмотра сайта при изменении настроек темы
 */
add_action(
	'customize_preview_init',
	function () {
		wp_enqueue_script(
			'clean-customizer',
			get_template_directory_uri() . '/customizer/customizer.js',
			array( 'customize-preview' ),
			null,
			true
		);
	}
);
