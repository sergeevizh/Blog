(function($) {
	// Изменяем цвет заголовка
	wp.customize( 'header_textcolor', function(value) {
		value.bind(function(to) {
			$('#blogname, #blogdescription').css('color', to);
		});
	} );
})(jQuery);
