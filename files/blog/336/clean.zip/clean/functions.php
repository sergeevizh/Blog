<?php
add_action('after_setup_theme', 'current_theme_setup');

function current_theme_setup() {

	/*
	 * Загружаем файл перевода темы в память
	 */
	load_theme_textdomain('clean', get_template_directory() . '/languages');

	/*
	 * Включаем поддержку форматов постов (это редко используется)
	 */
	add_theme_support(
		'post-formats',
		[
			'audio', 'video', 'gallery',
			/*
			'aside', 'link', 'image',
			'quote', 'status', 'chat'
			*/
		]
	);

	/*
	 * Добавляем поддержку автоматического добавления тега <title>
	 */
	add_theme_support('title-tag');

	/*
	 * Добавляем поддержку миниатюр для всех типов постов
	 */
	add_theme_support('post-thumbnails');

	/*
	 * Регистрируем расположение для двух меню — в шапке и в подвале
	 */
	register_nav_menus([
		'header_menu' => esc_html__('Меню в шапке', 'clean'),
		'footer_menu' => esc_html__('Меню в подвале', 'clean')
	]);

	/*
	 * Добавляем возможность загрузки своего фона для <body>
	 */
	add_theme_support(
		'custom-background',
		array(
			'default-color' => 'FFFFFF',
			'default-image' => '',
		)
	);

	/*
	 * Добавляем возможность установки фона для шапки сайта. Изменять
	 * можно не только фоновое изображение, но и цвет заголовка.
	 */
	add_theme_support(
		'custom-header',
		[
			'default-color' => 'FFFFFF',
			'default-text-color' => '000000',
			'default-image' => '',
			'width' => 3000,
			'height' => 500,
		]
	);

	/*
	 * Добавляем возможность загрузки своего логотипа
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height' => 250,
			'width' => 250,
			'flex-width' => true,
			'flex-height' => true,
		)
	);

	/*
	 * Добавляем поддержку selective refresh (выборочное обновление) в
	 * Theme Customizer для виджетов
	 */
	add_theme_support('customize-selective-refresh-widgets');
}

/*
 * Регистрируем место для сайдбара в боковой колонке
 */
add_action(
	'widgets_init',
	function () {
		register_sidebar(
			array(
				'name' => esc_html__('Боковая колонка', 'clean'),
				'id' => 'sidebar_right',
				'description' => esc_html__(
					'Перетащите сюда виджеты, чтобы добавить их в сайдбар',
					'clean'
				),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget' => '</section>',
				'before_title' => '<h3 class="widget-title">',
				'after_title' => '</h3>',
			)
		);
	}
);

/*
 * Подключаем файлы стилей и скриптов
 */
add_action(
	'wp_enqueue_scripts',
	function () {

		/*
		 * Подключаем файлы стилей
		 */
		wp_enqueue_style(
			'current-theme-bootstrap', // будет зарегистрирован под этим именем
			get_template_directory_uri() . '/assets/bs/css/bootstrap.min.css'
		);
		wp_enqueue_style(
			'current-theme-style', // будет зарегистрирован под этим именем
			get_template_directory_uri() . '/assets/css/style.css',
			// должен быть подключен после этих css-файлов
			[
				'current-theme-bootstrap'
			]
		);
		wp_enqueue_style(
			'default-theme-style', // будет зарегистрирован под этим именем
			get_stylesheet_uri(),
			// должен быть подключен после этих css-файлов
			[
				'current-theme-bootstrap',
				'current-theme-style'
			]
		);

		/*
		 * Подключаем файлы скриптов
		 */
		wp_enqueue_script(
			'current-theme-bootstrap', // будет зарегистрирован под этим именем
			get_template_directory_uri() . '/assets/bs/js/bootstrap.min.js',
			array('jquery'), // должен быть подключен после jquery
			null, // версии нет, поэтому null
			true // подключаем перед закрывающим тегом body
		);
		wp_enqueue_script(
			'current-theme-script', // будет зарегистрирован под этим именем
			get_template_directory_uri() . '/assets/js/script.js',
			array('jquery'), // должен быть подключен после jquery
			null, // версии нет, поэтому null
			true // подключаем перед закрывающим тегом body
		);
	}
);

/*
 * Задаем css-стили для элементов меню навигации, чтобы использовать
 * готовые стили Bootstrap 3
 */
add_filter(
	'nav_menu_css_class',
	function($classes, $item) {
		/*
		 * Переменная $classes содержит
		 * Array(
		 *   [1] => menu-item
		 *   [2] => menu-item-type-post_type
		 *   [3] => menu-item-object-page
		 *   [4] => menu-item-1911
		 * )
		 */
		// удаляем все css-классы, которые устанавливает WP
		$classes = [];
		if ($item->current) {
			// добавляем класс active для текущей страницы
			$classes[1] = 'active';
		}
		return $classes;
	},
	10,
	2
);

/*
 * Функция для вывода постраничной навигации с использованием классов
 * Bootstrap 3
 *
 * <nav aria-label="Постраничная навигация">
 *   <ul class="pagination">
 *       <li><a href="#">Предыдущая</a></li>
 *       <li><a href="#">1</a></li>
 *       <li class="active"><a href="#">2</a></li>
 *       <li><a href="#">3</a></li>
 *       <li class="disabled"><a href="#">…</a></li>
 *       <li><a href="#">9</a></li>
 *       <li><a href="#">Следующая</a></li>
 *   </ul>
 * </nav>
 */
function echo_posts_pagination($echo = true) {
	$items = paginate_links(['type' => 'array']);
	if (empty($items)) {
		return null;
	}

	$links = [];
	foreach ($items as $item) {
		$url = $txt = $type = '';
		if (preg_match('~href=("|\')([^"\']+)\1>([^<]+)</a>~', $item, $match)) {
			$url  = $match[2];
			$txt  = $match[3];
			$type = 'link';
		}
		if (preg_match('~page-numbers current("|\')>([^<]+)</span>~', $item, $match)) {
			$txt  = $match[2];
			$type = 'curr';
		}
		if (preg_match('~page-numbers dots("|\')>([^<]+)</span>~', $item, $match)) {
			$txt  = $match[2];
			$type = 'dots';
		}
		$links[] = ['type' => $type, 'url' => $url, 'txt' => $txt];
	}

	if (empty($links)) {
		return null;
	}

	$html = '<nav aria-label="Постраничная навигация">' . "\n";
	$html .= '  <ul class="pagination">' . "\n";
	foreach ($links as $link) {
		if ($link['type'] == 'link') {
			$html .= '    <li>';
			$html .= '<a href="'.$link['url'].'">'.$link['txt'].'</a>';
			$html .= '</li>' . "\n";
		} elseif ($link['type'] == 'curr') {
			$html .= '    <li class="active">';
			$html .= '<span>'.$link['txt'].'</span>';
			$html .= '</li>' . "\n";
		} elseif ($link['type'] == 'dots') {
			$html .= '    <li class="disabled">';
			$html .= '<span>'.$link['txt'].'</span>';
			$html .= '</li>' . "\n";
		}
	}
	$html .= '  </ul>' . "\n";
	$html .= '</nav>' . "\n";

	if ($echo) {
		echo $html;
		return null;
	}
	return $html;
}

/*
 * Подключаем настройщик темы (Theme Customiser)
 */
require get_template_directory() . '/customizer/customizer.php';
