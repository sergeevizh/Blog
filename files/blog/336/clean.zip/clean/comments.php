<?php
/**
 * Шаблон для вывода комментариев, файл comments.php
 */
?>

<div id="clean-comments">
	<?php
	if ( have_comments() ) :
		?>
		<h2><?php esc_html_e('Комментарии', 'clean'); ?></h2>
		<?php the_comments_navigation(); ?>
		<ol class="comment-list">
			<?php
			wp_list_comments([
				'style'      => 'ol',
				'short_ping' => true,
			]);
			?>
		</ol>
		<?php
		the_comments_navigation();
		if ( ! comments_open() ) :
			?>
			<p class="no-comments">
				<?php esc_html_e( 'Комментарии закрыты', 'clean' ); ?>
			</p>
			<?php
		endif;
	endif;
	comment_form();
	?>
</div>
