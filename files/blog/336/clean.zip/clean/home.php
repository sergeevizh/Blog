<?php
/**
 * Шаблон для показа списка последних постов, используется, когда на
 * главной странице показывается статическая страница. Файл home.php
 */

/*
 * Подключаем шапку сайта
 */
get_header();
?>

<div id="content">
	<div class="container">
		<div class="row">
			<main class="col-md-9">
				<?php get_template_part('parts/list'); ?>
			</main>
			<aside class="col-md-3">
				<?php get_sidebar(); ?>
			</aside>
		</div>
	</div>
</div>

<?php
/*
 * Подключаем подвал сайта
 */
get_footer();
