<?php
/*
 * Файл local/modules/scrollup/install/version.php
 */

$arModuleVersion = array(
    'VERSION'      => '1.0.0',
    'VERSION_DATE' => '2018-10-20 11:00:00'
);