<?php
/*
 * Файл local/modules/scrollup/lang/ru/install/index.php
 */

$MESS['SCROLLUP_NAME']              = 'Кнопка «Наверх»';
$MESS['SCROLLUP_DESCRIPTION']       = 'Добавляет на сайт кнопку плавной прокрутки наверх.';

$MESS['SCROLLUP_FILE_NOT_FOUND']    = 'Не найден файл';
$MESS['SCROLLUP_INSTALL_TITLE']     = 'Установка модуля';
$MESS['SCROLLUP_INSTALL_ERROR']     = 'Версия главного модуля ниже 14, обновите систему.';
$MESS['SCROLLUP_INSTALL_SUCCESS']   = 'Модуль успешно установлен';
$MESS['SCROLLUP_INSTALL_FAILED']    = 'Ошибка при установке модуля';

$MESS['SCROLLUP_UNINSTALL_TITLE']   = 'Удаление модуля';
$MESS['SCROLLUP_UNINSTALL_SUCCESS'] = 'Модуль успешно удален';
$MESS['SCROLLUP_UNINSTALL_FAILED']  = 'Ошибка при удалении модуля';

$MESS['SCROLLUP_RETURN_MODULES']    = 'Вернуться в список модулей';
